package oop.handwrite.emni.emni;

import java.io.Serializable;

public class Course implements Serializable  {
    private String courseId, title, type;
    private int noOfCredits;

    public Course() {
    }

    public Course(String courseId, int noOfCredits, String type, String title) {
        this.courseId = courseId;
        this.noOfCredits = noOfCredits;
        this.type = type;
        this.title = title;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public int getNoOfCredits() {
        return noOfCredits;
    }

    public void setNoOfCredits(int noOfCredits) {
        this.noOfCredits = noOfCredits;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseId='" + courseId + '\'' +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", noOfCredits=" + noOfCredits +
                '}';
    }

    public String toString(String reason) {
        return courseId+","+title+","+type+","+noOfCredits+"\n";
    }


}
