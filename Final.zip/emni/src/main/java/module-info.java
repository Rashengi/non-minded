module oop.handwrite.emni.emni {
    requires javafx.controls;
    requires javafx.fxml;


    opens oop.handwrite.emni.emni to javafx.fxml;
    exports oop.handwrite.emni.emni;
}